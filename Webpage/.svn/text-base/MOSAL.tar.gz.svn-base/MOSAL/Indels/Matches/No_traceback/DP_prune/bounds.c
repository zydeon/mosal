/****************************************************************************

 It computes the set of non dominated scores for the #Matches-#Indels problem
 without traceback (only final scores). It is a Dynamic Programming
 (DP) with pruning approach, by filling a DP matrix - P
 (with dimensions (M+1)*(N+1), where M and N are the sizes of the 1st and
 2nd sequence respectively).
 Each entry P[i,j] will store the set of states corresponding to Pareto
 optimal alignments of subsequences (a_1,...,a_i) and (b_1,...,b_j).

 ---------------------------------------------------------------------

    Copyright (c) 2013

		Maryam Abassi    (maryam@dei.uc.pt)
		Luís Paquete     (paquete@dei.uc.pt)
		Arnaud Liefooghe (arnaud.liefooghe@univ-lille1.fr)
		Miguel Pinheiro  (monsanto@biocant.pt)
		Pedro Matias     (pamatias@student.dei.uc.pt)

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, you can obtain a copy of the GNU
 General Public License at:
                 http://www.gnu.org/copyleft/gpl.html
 or by writing to:
           Free Software Foundation, Inc., 59 Temple Place,
                 Suite 330, Boston, MA 02111-1307 USA

****************************************************************************/

/**
 * Implementation of the functions in 'bounds.h'.
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "bounds.h"

void init_bounds( int mid_bounds ){
	MID_BOUNDS_NUM = mid_bounds;
	BOUNDS_NUM     = mid_bounds + 2;	

	init_lower_bound( );
	calculate_lower_bound( );

	init_upper_bound( );
	calculate_upper_bound( );
}

void init_lower_bound( ){
	int i, j, m;

	LB = (VMD *) malloc( BOUNDS_NUM * sizeof(VMD) );

	/* L malloc (MAX and MIN) */		
	L = (VMD **) malloc( (M+1)*sizeof(VMD *) );
	for( i = 0; i < M+1; ++i )
		L[i] = (VMD *) malloc( (N+1)*sizeof(VMD) );

	/* base cases */
	L[0][0].matches = 0;
	L[0][0].indels  = 0;
	for( i = 1; i < M+1; ++i ){
		L[i][0].matches = 0;
		L[i][0].indels  = i;
	}
	for( j = 1; j < N+1; ++j ){
		L[0][j].matches = 0;
		L[0][j].indels  = j;
	}

	/* M's mallocs (MID's) */
	M_ = (VMD ***) malloc( MID_BOUNDS_NUM*sizeof(VMD **) );
	for( m = 0; m < MID_BOUNDS_NUM; ++m ){
		/* allocs */
		M_[m] = (VMD **) malloc( (M+1)*sizeof(VMD *) );
		for( i = 0; i < M+1; ++i )
			M_[m][i] = (VMD *) malloc( (N+1)*sizeof(VMD) );
		
		/* base cases */
		M_[m][0][0].matches = 0;
		M_[m][0][0].indels  = 0;
		for( i = 1; i < M+1; ++i ){
			M_[m][i][0].matches = 0;	M_[m][i][0].indels = i;
		}
		for( j = 1; j < N+1; ++j ){
			M_[m][0][j].matches = 0; 	M_[m][0][j].indels = j;
		}		
	}
}

void calculate_lower_bound( ){
	int i, m;

	calc_MAX();
	calc_MIN();
	calc_MID();

	/* remove tables (not needed anymore) */
	for( i = 0; i < M+1; ++i )
		free( L[i] );
	
	free(L);

	for( m = 0; m < MID_BOUNDS_NUM; ++m ){
		for( i = 0; i < M+1; ++i )
			free( M_[m][i] );

		free( M_[m] );	
	}

	/*  calculates the maximum number of scores vectors per cell
		(used to allocate memory for the main DP table)
	*/
	MAX_STATES = min2( MAX->matches-MIN->matches, MAX->indels-MIN->indels ) + 1;	
}

void calc_MAX(){
	int i, j, match;
	/* LexMDP */
	for( i = 1; i < M+1; ++i ){
		for( j = 1; j < N+1; ++j ){
			match = seq1[i-1] == seq2[j-1];
			L[i][j] = lexmaxM( L[i-1][j], L[i][j-1], L[i-1][j-1], match );
		}
	}
	LB[ BOUNDS_NUM-1 ] = L[M][N];
	MAX = &LB[ BOUNDS_NUM-1 ] ;
	// printf("MAX=(%d,%d)\n", MAX->matches, MAX->indels );
}

void calc_MIN(){
	int i, j,match;
	/* LexDMP */
	for( i = 1; i < M+1; ++i ){
		for( j = 1; j < N+1; ++j ){
			match = seq1[i-1] == seq2[j-1];
			L[i][j] = lexminD( L[i-1][j], L[i][j-1], L[i-1][j-1], match );
		}
	}
	LB[0] = L[M][N];
	MIN = &LB[0];
	//printf("MIN=(%d,%d)\n", MIN->matches, MIN->indels);
}

void calc_MID(){
	int m, i, j, ws, wd, match;

	for( m = 0; m < MID_BOUNDS_NUM; ++m ){
		for( i = 1; i < M+1; ++i ){
			for( j = 1; j < N+1; ++j ){
				
				match = seq1[i-1] == seq2[j-1];
				ws = m + 1;
				wd = MID_BOUNDS_NUM - m;

				M_[m][i][j] = scalar_max( M_[m][i-1][j], M_[m][i][j-1], M_[m][i-1][j-1], match, ws, wd );

			}
		}
		LB[m+1] = M_[m][M][N];
		//printf("MID=(%d,%d)\n", M_[m][M][N].matches, M_[m][M][N].indels );
	}
}

void init_upper_bound( ){
	int i;
	
	U = (VMD **) malloc( (M+1)*sizeof(VMD *) );
	for( i = 0; i <= M; ++i )
		U[i] = (VMD *) malloc( (N+1)*sizeof(VMD) );
}

void calculate_upper_bound( ){
	/**
	 * Based on the classical DP algorithm for computing the LCS
	 * in the reversed sequences.
	 */
	
	int i, j ;
	/* base cases */
	U[M][N].matches = 0;
	U[M][N].indels  = 0;
	for( i = 0; i < M; ++i ){
		U[i][N].matches = 0;
		U[i][N].indels  = M-i ;
	}
	for( j = 0; j < N; ++j ){
		U[M][j].matches = 0;
		U[M][j].indels  = (N-j) ;
	}	
	for( i = M-1; i >= 0; --i ){			/* begins in the oposite corner of the table (reversed sequences) */
		for( j = N-1; j >= 0; --j ){
			if( seq1[i] == seq2[j] ){
				U[i][j].matches = U[i+1][j+1].matches + 1;
				U[i][j].indels  = abs( (M-i)-(N-j) ) ;
			}	
			else{
				U[i][j].matches = max2(U[i+1][j].matches , U[i][j+1].matches);
				U[i][j].indels  = abs( (M-i)-(N-j) ) ;
			}
		}
	}
}

VMD lexmaxM( VMD up, VMD left, VMD diagonal, int match ){
	/* match priority */
	VMD result;
	int mu, ml, md, iu, il, id;		/* auxiliar variables */

	mu = up.matches;
	ml = left.matches;
	md = diagonal.matches + match;
	
	iu = up.indels + 1;
	il = left.indels + 1;
	id = diagonal.indels;

	if( mu > ml ){
		if( mu > md ){
			result.matches = mu;
			result.indels  = iu;
		}
		else if( mu == md ){
			if( iu <= id ){
				result.matches = mu;
				result.indels  = iu;	
			}
			else{
				result.matches = md;
				result.indels  = id;				
			}
		}
		else{
			result.matches = md;
			result.indels  = id;			
		}
	}
	else if( mu == ml ){
		if( mu > md ){
			if( iu <= il ){
				result.matches = mu;
				result.indels  = iu;
			}
			else{
				result.matches = ml;
				result.indels  = il;				
			}
		}
		else if( mu == md ){
			if( iu <= il ){
				if( iu <= id ){
					result.matches = mu;
					result.indels  = iu;					
				}
				else{
					result.matches = md;
					result.indels  = id;					
				}
			}
			else{
				if( il <= id ){
					result.matches = ml;
					result.indels  = il;					
				}
				else{
					result.matches = md;
					result.indels  = id;					
				}
			}
		}
		else{			/* mu < md */
			result.matches = md;
			result.indels  = id;			
		}
	}
	else{				/* mu < ml */
		if( ml > md ){
			result.matches = ml;
			result.indels  = il;			
		}
		else if( ml == md){
			if( il <= id ){
				result.matches = ml;
				result.indels  = il;				
			}
			else{
				result.matches = md;
				result.indels  = id;			
			}
		}
		else{
			result.matches = md;
			result.indels  = id;						
		}
	}

	return result;
}


VMD lexminD( VMD up, VMD left, VMD diagonal, int match ){
	/* indels priority */

	VMD result;
	int mu, ml, md, iu, il, id;			/* auxiliar variables */

	mu = up.matches;
	ml = left.matches;
	md = diagonal.matches + match;
	
	iu = up.indels + 1;
	il = left.indels + 1;
	id = diagonal.indels;

	if( iu < id ){
		if( iu < il ){
			result.matches = mu;
			result.indels  = iu;			
		}
		else if( iu == il && mu >= ml ){
			result.matches = mu;
			result.indels  = iu;			
		}
		else{
			result.matches = ml;
			result.indels  = il;							
		}
	}

	else if( iu == id ){

		if( il < iu ){
			result.matches = ml;
			result.indels  = il;
		}
		else if( iu == il ){
			if( mu >= md ){
				if( mu >= ml ){
					result.matches = mu;
					result.indels  = iu;
				}
				else{
					result.matches = ml;
					result.indels  = il;
				}
			}
			else{
				if( md >= ml ){
					result.matches = md;
					result.indels  = id;
				}
				else{
					result.matches = ml;
					result.indels  = il;
				}
			}
		}
		else{			/* iu==id && iu < il */
			if( mu >= md ){
				result.matches = mu;
				result.indels  = iu;
			}
			else{
				result.matches = md;
				result.indels  = id;
			}
		}
	}

	else{

		if( id < il ){
			result.matches = md;
			result.indels  = id;
		}
		else if( id == il && md >= ml ){
			result.matches = md;
			result.indels  = id;			
		}
		else{
			result.matches = ml;
			result.indels  = il;								
		}
	}	


	return result;
}

VMD scalar_max( VMD up, VMD left, VMD diagonal, int match, int ws, int wd ){
	VMD result;

	/* auxiliar variables */
	int iu, il, id;
	int mu, ml, md;
	int ru, rl, rd;		/* temporary results */

	iu = up.indels + 1;
	il = left.indels + 1;
	id = diagonal.indels;

	mu = up.matches;
	ml = left.matches;
	md = diagonal.matches + match;

	ru = ws * mu - wd * iu;
	rl = ws * ml - wd * il;
	rd = ws * md - wd * id;

	if( ru >= rl ){
		if( ru >= rd ){
			result.matches = mu;
			result.indels  = iu;
		}
		else{
			result.matches = md;
			result.indels  = id;
		}
	}
	else{
		if( rl >= rd ){
			result.matches = ml;
			result.indels  = il;
		}
		else{
			result.matches = md;
			result.indels  = id;
		}
	}

	return result;
}

void prune( Pareto_set *set, int i, int j ){
	/**
	 * If the current score vector plus the corresponding upper bound
	 * score vector is dominated by any of the lower bound scores, than
	 * it is pruned.
	 */
	int k;

	/* auxiliar variables 'm', 'd' */
	int m = set->scores[ set->num-1 ].matches + U[i][j].matches;
	int d = set->scores[ set->num-1 ].indels + U[i][j].indels;

	k = 0;
    while( k < BOUNDS_NUM && LB[k].matches < m ) k++;	/* advance in bound scores */

    if( k < BOUNDS_NUM ){
        if( m == LB[k].matches ){
            if( d > LB[k].indels ){
                set->num--;        
            }    
        }
        else{
            if( d >= LB[k].indels ){
                set->num--;        
            }
        }
    }
    else{	/* advanced all bounds (this should never happen) */
        set->num--;
	}
}

int min2(int n1, int n2){
	return n1 <= n2 ? n1 : n2;
}
int max2(int n1, int n2){
	return n1 >= n2 ? n1 : n2;
}

void remove_bounds_tables(){
	int i;

	free(LB);

	for( i = 0; i < M+1; ++i ){
		free( U[i] );
	}
	free(U);
}